

# import models
#
#
# all_stream =[
# "Computer Engineering",
# "Software Engineering",
# "Artificial Intelligence",
# "Machine Learning",
# "Economics",
# "Data Science",
# "Jounalisms"
# ]
#
#
# for strem_name in all_stream:
#     obj = models.Stream(name=strem_name)
#     obj.save()
#     print("Added Stream : {strem_name}")
#
# print("Finishaed Adding the streams:")
